---
name: pixel-ppt-skill
description: 生成、改写和校验复古像素游戏风格的 1920×1080 横版 HTML PPT，提供封面、目录、小节页、10 种商业内容版式、离线字体、键盘/点击/缩略图导航、像素转场和 PDF 打印样式。用于用户要求 Pixel Art、8-bit、Retro Game UI、未来科技商业路演网页演示稿，或需要把文档、提纲、图片整理成可直接打开的 HTML deck 时。
---

# Pixel Art HTML PPT

基于 `assets/template/` 生成离线多文件 HTML 演示稿。保持 1920×1080 内部画布、JSON 页面数据、统一渲染器和像素视觉系统。

## 工作流

### 1. 创建项目

运行脚手架，不要手工重写模板：

```bash
SKILL_ROOT="${CODEX_HOME:-$HOME/.codex}/skills/pixel-ppt-skill"
node "$SKILL_ROOT/scripts/scaffold-deck.mjs" "输出目录/pixel-deck"
```

模板包含 13 页完整示例、4 种转场、左侧缩略图、底部导航、响应式缩放和 PDF 打印样式。直接打开 `index.html`，不要改为需要服务器或构建工具的框架。

### 2. 整理内容与素材

先建立大纲，再选择版式：

- 固定保留第 1 页 `cover`、第 2 页 `agenda`、第 3 页 `section`。
- 固定让 `ending` 成为最后一页。
- 每个一级章节前插入一个 `section`，不要只靠目录区分章节。
- 一页只表达一个主要观点；内容过多时复制同类型页面，不要压缩到不可读。
- 用户提供文档或图片时，先提取全部素材并按原文顺序建立“标题/段落/图片”对应关系。
- 将图片复制到输出项目的 `assets/images/`，不要引用临时目录或远程 URL。

阅读 `references/content-layouts.md`，按内容意图选择页面类型和字段。处理真实图片时使用其中的图片适配规则。

### 3. 修改页面数据

只在 `script.js` 的 `SLIDES_DATA_START` 与 `SLIDES_DATA_END` 之间编辑 `slides` 数组；优先复用现有 renderer，不要把页面改成散落的硬编码 HTML。

每页保持：

```js
{
  id: "unique-id",
  type: "data",
  title: "Thumbnail label",
  transition: "pixel-block",
  content: {}
}
```

约束：

- `id` 全局唯一，使用小写短横线命名。
- `type` 使用模板已支持的 13 种类型。
- `transition` 只能是 `pixel-block`、`scan-line`、`pixel-slide`、`ui-loading`。
- 目录 `items` 的最后一个数字是零基页面索引；增删页面后同步更新。
- 示例中英文标题配中文正文；英文标题尽量短，避免超过一行宽度。
- 保持主题色 `#D1FFFF`、`#0057A8`、`#B45CFF`、`#FFB7E8`、`#F5FCFF`。

### 4. 适配图片和版式数量

- `intro`、`product`、`case` 支持可选 `content.image` 和 `content.imageAlt`。
- 图片路径使用 `assets/images/filename.ext`，必须设置有意义的替代文字。
- 模板统一使用 `object-fit: contain`，不要裁掉界面、海报、图表或产品主体。
- 同一段落有 2-6 张图时扩展为网格；图片更多时拆成连续页并保持原顺序。
- 条目少于示例时删除尾部空卡；条目多时复制相同结构或拆页，不留下占位文本。
- 只有用户明确要求时才改变像素配色、边框语言或低饱和浅蓝背景。

### 5. 保持交互与工程约束

- 保持 `index.html`、`style.css`、`script.js` 和 `assets/` 的相对路径。
- 不添加 CDN、`fetch()`、ES Module、框架或构建步骤，确保 `file://` 可运行。
- 保持 1920×1080 舞台和 `Math.min(innerWidth / 1920, innerHeight / 1080)` 等比缩放。
- 保持键盘左右键、页面左右点击、圆点导航和左侧 80px 缩略图触发区。
- 交互控件必须阻止背景翻页；首尾页不循环。
- 动画优先使用 CSS transform/opacity，避免逐帧 DOM 计算。
- 保留 `@media print` 和 16:9 `@page`，确保可导出为一页一张的 PDF。

### 6. 校验与预览

先读 `references/checklist.md`，再运行：

```bash
node "$SKILL_ROOT/scripts/validate-deck.mjs" "输出目录/pixel-deck"
```

校验技能自带模板时运行：

```bash
node "$SKILL_ROOT/scripts/validate-deck.mjs" "$SKILL_ROOT/assets/template" --template
```

最后直接打开 `index.html`，逐页检查文字溢出、卡片重叠、图片裁切、缩略图和四类转场。至少检查 1920×1080、1440×900、1366×768 三种窗口。

## 文件导览

```text
pixel-ppt-skill/
├── SKILL.md
├── agents/openai.yaml
├── assets/template/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   └── assets/fonts/
├── references/
│   ├── content-layouts.md
│   └── checklist.md
└── scripts/
    ├── scaffold-deck.mjs
    └── validate-deck.mjs
```
