/*
 * Pixel Pitch Deck — phase 1
 * Keep the slide data in this file so the deck can run directly from file://.
 */

// SLIDES_DATA_START — edit this array to build a new deck.
const slides = [
  {
    id: "cover",
    type: "cover",
    title: "Pixel Concept",
    transition: "pixel-block",
    content: {
      eyebrow: "FUTURE TECH · PITCH DECK",
      title: "PIXEL\nCONCEPT",
      subtitle: "把商业想法，变成一场可玩的未来体验",
      button: "START",
      meta: "2026 / SHANGHAI"
    }
  },
  {
    id: "agenda",
    type: "agenda",
    title: "Agenda",
    transition: "scan-line",
    content: {
      eyebrow: "SELECT YOUR LEVEL",
      title: "AGENDA",
      items: [
        ["01", "数字表现", "DATA & GROWTH", 3],
        ["02", "产品路径", "PRODUCT & FLOW", 6],
        ["03", "市场洞察", "MARKET & CASE", 9],
        ["04", "团队与未来", "TEAM & NEXT", 12]
      ]
    }
  },
  {
    id: "section-01",
    type: "section",
    title: "Chapter 01",
    transition: "pixel-slide",
    content: {
      number: "01",
      kicker: "CHAPTER ONE",
      title: "BUILD THE\nNEXT LEVEL",
      text: "从核心指标出发，建立可持续增长的产品系统。"
    }
  },
  {
    id: "data",
    type: "data",
    title: "Data Dashboard",
    transition: "ui-loading",
    content: {
      title: "NUMBERS",
      subtitle: "关键指标 / KEY METRICS",
      metrics: [
        { icon: "◆", value: "98%", label: "客户满意度", delta: "+12%" },
        { icon: "♟", value: "780", label: "活跃客户", delta: "+28%" },
        { icon: "▣", value: "60+", label: "覆盖城市", delta: "+09" },
        { icon: "◎", value: "300K", label: "月度访问", delta: "+42%" },
        { icon: "▤", value: "2M", label: "内容触达", delta: "+65%" },
        { icon: "★", value: "4.9", label: "产品评分", delta: "TOP 1" }
      ]
    }
  },
  {
    id: "intro",
    type: "intro",
    title: "About Product",
    transition: "pixel-block",
    content: {
      title: "WHAT WE DO_?",
      subtitle: "关于我们的产品",
      body: "我们把复杂的数字工具，重新设计成轻量、清晰且有趣的体验。每一步操作都像游戏任务一样自然，让团队更快抵达结果。",
      tags: ["PLAYFUL", "EFFICIENT", "SCALABLE"]
    }
  },
  {
    id: "timeline",
    type: "timeline",
    title: "Timeline",
    transition: "scan-line",
    content: {
      title: "TIMELINE",
      subtitle: "从概念验证到规模增长",
      steps: [
        ["Q1", "DISCOVER", "用户研究"],
        ["Q2", "DESIGN", "产品原型"],
        ["Q3", "LAUNCH", "市场发布"],
        ["Q4", "LEVEL UP", "规模增长"]
      ]
    }
  },
  {
    id: "flow",
    type: "flow",
    title: "Flow Chart",
    transition: "pixel-slide",
    content: {
      title: "MISSION FLOW",
      subtitle: "一条清晰、可复用的增长路径",
      steps: [
        ["01", "INPUT", "收集信号"],
        ["02", "MAP", "识别机会"],
        ["03", "BUILD", "快速构建"],
        ["04", "TEST", "持续验证"],
        ["05", "WIN", "放大成果"]
      ]
    }
  },
  {
    id: "team",
    type: "team",
    title: "Team",
    transition: "ui-loading",
    content: {
      title: "MEET THE TEAM",
      subtitle: "小队成员 / PLAYER SELECT",
      members: [
        ["MIA", "PRODUCT", "A"],
        ["LEO", "DESIGN", "B"],
        ["NOVA", "TECH", "C"],
        ["KAI", "GROWTH", "D"]
      ]
    }
  },
  {
    id: "product",
    type: "product",
    title: "Product",
    transition: "pixel-block",
    content: {
      title: "PRODUCT SYSTEM",
      subtitle: "一套工具，解锁完整工作流",
      features: ["实时数据面板", "智能任务编排", "模块化内容系统", "多端协作体验"],
      specs: [["SPEED", "98"], ["POWER", "86"], ["EASE", "94"]]
    }
  },
  {
    id: "analysis",
    type: "analysis",
    title: "Market Analysis",
    transition: "scan-line",
    content: {
      title: "MARKET ANALYSIS",
      subtitle: "趋势正在加速，窗口已经打开",
      bars: [34, 48, 57, 71, 86],
      years: ["22", "23", "24", "25", "26"],
      ratios: [["48%", "市场增速"], ["72%", "用户意愿"], ["3.6X", "价值空间"]]
    }
  },
  {
    id: "case",
    type: "case",
    title: "Case Study",
    transition: "pixel-slide",
    content: {
      title: "CASE STUDY",
      subtitle: "从 0 到 1 的一次通关记录",
      client: "PROJECT ORBIT",
      body: "通过重构信息架构与核心任务链路，团队在八周内完成产品升级，并建立可持续的数据反馈机制。",
      results: [["+126%", "转化率"], ["-38%", "操作时间"], ["4.8", "用户评分"]]
    }
  },
  {
    id: "comparison",
    type: "comparison",
    title: "Comparison",
    transition: "ui-loading",
    content: {
      title: "CHOOSE YOUR MODE",
      subtitle: "旧路径 VS 新体验",
      left: { name: "CLASSIC", badge: "BEFORE", items: ["流程分散", "反馈延迟", "维护成本高"] },
      right: { name: "PIXEL PRO", badge: "AFTER", items: ["统一工作台", "实时反馈", "模块化扩展"] }
    }
  },
  {
    id: "ending",
    type: "ending",
    title: "Game Clear",
    transition: "pixel-block",
    content: {
      kicker: "MISSION COMPLETE",
      title: "GAME CLEAR!",
      subtitle: "下一关，和我们一起开始。",
      contact: "hello@pixelconcept.studio",
      action: "REPLAY"
    }
  }
];
// SLIDES_DATA_END

const state = {
  current: 0,
  locked: false,
  reducedMotion: window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  hideRailTimer: null
};

const dom = {};

const escapeHTML = (value = "") => String(value)
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const lines = (value) => escapeHTML(value).replaceAll("\n", "<br>");

function pixelLetters(value) {
  let order = 0;
  return String(value).split("").map((character) => {
    if (character === "\n") return "<br>";
    const printable = character === " " ? "&nbsp;" : escapeHTML(character);
    return `<span style="--char:${order++}">${printable}</span>`;
  }).join("");
}

function pixelCloud(className = "") {
  return `<div class="pixel-cloud ${className}" aria-hidden="true"><i></i><i></i><i></i><i></i></div>`;
}

function pageChrome(slide, index) {
  return `
    <div class="slide-topline">
      <span><i class="signal-dot"></i> PIXEL CONCEPT / ${String(index + 1).padStart(2, "0")}</span>
      <span class="hearts" aria-hidden="true">♡♡♡</span>
    </div>
    ${pixelCloud("cloud-a")}
    ${pixelCloud("cloud-b")}
    <div class="pixel-sparkles" aria-hidden="true"><i>✦</i><i>＋</i><i>·</i><i>✦</i></div>
    <div class="slide-grid" aria-hidden="true"></div>
    <div class="page-floor" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
  `;
}

function slideHeading(content) {
  return `
    <header class="content-heading">
      <p>${escapeHTML(content.subtitle || "PIXEL BUSINESS TEMPLATE")}</p>
      <h2>${lines(content.title)}</h2>
    </header>
  `;
}

const renderers = {
  cover(slide) {
    const c = slide.content;
    return `
      <div class="cover-sky">
        ${pixelCloud("cover-cloud-one")}${pixelCloud("cover-cloud-two")}
        <div class="cover-stars" aria-hidden="true">✦　·　✦　·　✦</div>
        <div class="cover-copy">
          <p class="eyebrow">${escapeHTML(c.eyebrow)}</p>
          <h1 class="pixel-title" data-typing-title>${pixelLetters(c.title)}</h1>
          <p class="cover-subtitle">${escapeHTML(c.subtitle)}</p>
          <button class="pixel-button" type="button" data-action="next">${escapeHTML(c.button)}</button>
        </div>
        <div class="cover-side-note"><b>PITCH DECK DESIGN</b><span>${escapeHTML(c.meta)}</span></div>
      </div>
      <div class="pixel-city" aria-hidden="true">${Array.from({ length: 19 }, (_, i) => `<i style="--h:${58 + (i * 37) % 150}px"></i>`).join("")}</div>
      <div class="game-ground" aria-hidden="true"><span class="speech speech-one">★</span><span class="speech speech-two">♥</span><span class="player player-one"></span><span class="player player-two"></span></div>
    `;
  },

  agenda(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 1)}
      <div class="agenda-layout">
        <section>
          <p class="eyebrow">${escapeHTML(c.eyebrow)}</p>
          <h2>${escapeHTML(c.title)}</h2>
          <div class="agenda-list">
            ${c.items.map((item) => `
              <button type="button" class="agenda-item" data-go-to="${item[3]}">
                <b>${escapeHTML(item[0])}</b><span>${escapeHTML(item[1])}<small>${escapeHTML(item[2])}</small></span><i>▶</i>
              </button>`).join("")}
          </div>
        </section>
        <div class="agenda-art" aria-hidden="true">
          <div class="pixel-window"><div class="window-bar"></div><div class="pixel-sun"></div><div class="pixel-mountain"></div></div>
          <div class="mini-controller"><i></i><b>+</b><span>● ●</span></div>
        </div>
      </div>
    `;
  },

  section(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 2)}
      <div class="section-layout">
        <div class="section-number">${escapeHTML(c.number)}</div>
        <div class="section-copy">
          <p class="eyebrow">${escapeHTML(c.kicker)}</p>
          <h2>${lines(c.title)}</h2>
          <p>${escapeHTML(c.text)}</p>
        </div>
        <div class="section-cubes" aria-hidden="true">${Array.from({ length: 16 }, (_, i) => `<i style="--i:${i};--x:${i % 8};--y:${Math.floor(i / 8)}"></i>`).join("")}</div>
      </div>
    `;
  },

  data(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 3)}
      <div class="content-layout">
        ${slideHeading(c)}
        <div class="metric-grid">
          ${c.metrics.map((m, index) => `
            <article class="metric-card">
              <span class="metric-icon metric-icon-${index + 1}"><i></i><b>${escapeHTML(m.icon)}</b></span>
              <div><strong>${escapeHTML(m.value)}</strong><h3>${escapeHTML(m.label)}</h3></div>
              <em>${escapeHTML(m.delta)}</em>
            </article>`).join("")}
        </div>
      </div>
    `;
  },

  intro(slide) {
    const c = slide.content;
    const visual = c.image
      ? `<img class="fit-img" src="${escapeHTML(c.image)}" alt="${escapeHTML(c.imageAlt || c.title)}">`
      : `<span class="scene-sun"></span><span class="scene-grid"></span><span class="scene-road"></span><span class="scene-palm palm-one"></span><span class="scene-palm palm-two"></span><b>NEW<br>HORIZON</b>`;
    return `
      ${pageChrome(slide, 4)}
      <div class="split-layout intro-layout">
        <div class="browser-art" aria-label="示例产品图片占位">
          <div class="window-bar"><i></i><i></i><i></i></div>
          <div class="browser-scene ${c.image ? "with-image" : ""}">${visual}</div>
        </div>
        <section class="intro-copy">
          <p class="eyebrow">${escapeHTML(c.subtitle)}</p>
          <h2>${escapeHTML(c.title)}</h2>
          <p>${escapeHTML(c.body)}</p>
          <div class="tag-row">${c.tags.map((tag) => `<span>${escapeHTML(tag)}</span>`).join("")}</div>
        </section>
      </div>
    `;
  },

  timeline(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 5)}
      <div class="content-layout">
        ${slideHeading(c)}
        <div class="timeline-track">
          ${c.steps.map((step, i) => `
            <article class="timeline-step">
              <span class="timeline-node">${i % 2 ? "◆" : "★"}</span>
              <div><b>${escapeHTML(step[0])}</b><h3>${escapeHTML(step[1])}</h3><p>${escapeHTML(step[2])}</p></div>
            </article>`).join("")}
        </div>
        <div class="pixel-platform" aria-hidden="true"></div>
      </div>
    `;
  },

  flow(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 6)}
      <div class="content-layout">
        ${slideHeading(c)}
        <div class="flow-row">
          ${c.steps.map((step, i) => `
            <article class="flow-step"><b>${escapeHTML(step[0])}</b><span class="flow-icon">${["!", "?", "+", "✓", "★"][i]}</span><h3>${escapeHTML(step[1])}</h3><p>${escapeHTML(step[2])}</p></article>
            ${i < c.steps.length - 1 ? `<i class="flow-arrow" aria-hidden="true">▶</i>` : ""}`).join("")}
        </div>
      </div>
    `;
  },

  team(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 7)}
      <div class="content-layout">
        ${slideHeading(c)}
        <div class="team-lead" aria-hidden="true"><span>★</span><b>CORE TEAM</b></div>
        <div class="team-line" aria-hidden="true"></div>
        <div class="team-grid">
          ${c.members.map((member, i) => `
            <article class="team-card">
              <div class="avatar avatar-${i + 1}"><span class="avatar-hair"></span><span class="avatar-face"><i></i></span><span class="avatar-body"></span></div>
              <h3>${escapeHTML(member[0])}</h3><p>${escapeHTML(member[1])}</p><small>PLAYER 0${i + 1}</small>
            </article>`).join("")}
        </div>
      </div>
    `;
  },

  product(slide) {
    const c = slide.content;
    const productVisual = c.image
      ? `<img class="fit-img" src="${escapeHTML(c.image)}" alt="${escapeHTML(c.imageAlt || c.title)}">`
      : `<span>PIXEL OS</span><strong>READY_</strong><i></i>`;
    return `
      ${pageChrome(slide, 8)}
      <div class="content-layout product-layout">
        ${slideHeading(c)}
        <div class="product-console" aria-label="产品系统像素插画">
          <div class="product-screen ${c.image ? "has-image" : ""}">${productVisual}</div>
          <div class="console-controls"><b>+</b><span>● ●</span></div>
        </div>
        <div class="product-info">
          <div class="feature-list">${c.features.map((feature, i) => `<p><b>0${i + 1}</b>${escapeHTML(feature)}<i>✓</i></p>`).join("")}</div>
          <div class="spec-list">${c.specs.map((spec) => `<p><span>${escapeHTML(spec[0])}</span><i><b style="width:${spec[1]}%"></b></i><strong>${escapeHTML(spec[1])}</strong></p>`).join("")}</div>
        </div>
      </div>
    `;
  },

  analysis(slide) {
    const c = slide.content;
    return `
      ${pageChrome(slide, 9)}
      <div class="content-layout analysis-layout">
        ${slideHeading(c)}
        <div class="chart-window">
          <div class="window-bar"><span>GROWTH.EXE</span></div>
          <div class="bar-chart">
            ${c.bars.map((bar, i) => `<div class="bar-column"><i style="height:${bar}%"><b>${bar}</b></i><span>${escapeHTML(c.years[i])}</span></div>`).join("")}
            <svg class="trend-line" viewBox="0 0 600 260" preserveAspectRatio="none" aria-hidden="true"><polyline points="45,205 175,170 300,140 425,90 555,45"></polyline></svg>
          </div>
        </div>
        <div class="ratio-stack">${c.ratios.map((ratio) => `<article><strong>${escapeHTML(ratio[0])}</strong><span>${escapeHTML(ratio[1])}</span></article>`).join("")}</div>
      </div>
    `;
  },

  case(slide) {
    const c = slide.content;
    const caseVisual = c.image
      ? `<img class="fit-img" src="${escapeHTML(c.image)}" alt="${escapeHTML(c.imageAlt || c.client || c.title)}">`
      : `<span>ORBIT<br>ONLINE</span><i></i><b></b><div class="case-orbit"><em></em><em></em><em></em></div><div class="case-city"></div>`;
    return `
      ${pageChrome(slide, 10)}
      <div class="content-layout case-layout">
        ${slideHeading(c)}
        <div class="case-visual ${c.image ? "has-image" : ""}" aria-label="${escapeHTML(c.imageAlt || "案例像素插画")}">${caseVisual}</div>
        <div class="case-copy"><p class="eyebrow">${escapeHTML(c.client)}</p><p>${escapeHTML(c.body)}</p><div class="case-results">${c.results.map((r) => `<article><strong>${escapeHTML(r[0])}</strong><span>${escapeHTML(r[1])}</span></article>`).join("")}</div></div>
      </div>
    `;
  },

  comparison(slide) {
    const c = slide.content;
    const column = (data, featured) => `<article class="compare-card ${featured ? "featured" : ""}"><span class="compare-badge">${escapeHTML(data.badge)}</span><div class="compare-face">${featured ? "★" : "×"}</div><h3>${escapeHTML(data.name)}</h3>${data.items.map((item) => `<p><i>${featured ? "✓" : "–"}</i>${escapeHTML(item)}</p>`).join("")}</article>`;
    return `
      ${pageChrome(slide, 11)}
      <div class="content-layout comparison-layout">
        ${slideHeading(c)}
        <div class="comparison-grid">${column(c.left, false)}<div class="versus">VS</div>${column(c.right, true)}</div>
      </div>
    `;
  },

  ending(slide) {
    const c = slide.content;
    return `
      <div class="ending-stars" aria-hidden="true">${Array.from({ length: 24 }, (_, i) => `<i style="--i:${i};--x:${(i * 83) % 100};--y:${(i * 47) % 90}">✦</i>`).join("")}</div>
      <div class="ending-panel">
        <p class="eyebrow">${escapeHTML(c.kicker)}</p>
        <div class="pixel-trophy" aria-hidden="true"><span>★</span><i></i></div>
        <h2>${escapeHTML(c.title)}</h2>
        <p>${escapeHTML(c.subtitle)}</p>
        <a href="mailto:${escapeHTML(c.contact)}" data-interactive>${escapeHTML(c.contact)}</a>
        <button class="pixel-button" type="button" data-action="replay">${escapeHTML(c.action)}</button>
      </div>
      <div class="ending-ground" aria-hidden="true"><span class="ending-player ep-one"></span><span class="ending-player ep-two"></span><span class="ending-player ep-three"></span></div>
    `;
  }
};

function renderDeck() {
  dom.stage.innerHTML = slides.map((slide, index) => {
    const renderer = renderers[slide.type];
    if (!renderer) throw new Error(`Unknown slide type: ${slide.type}`);
    return `<section class="slide slide-${slide.type}${index === 0 ? " is-active" : ""}" data-slide-index="${index}" aria-hidden="${index === 0 ? "false" : "true"}" aria-label="第 ${index + 1} 页：${escapeHTML(slide.title)}">${renderer(slide)}</section>`;
  }).join("");

  dom.dots.innerHTML = slides.map((slide, index) => `
    <button type="button" class="nav-dot${index === 0 ? " is-active" : ""}" data-go-to="${index}" aria-label="跳转到第 ${index + 1} 页：${escapeHTML(slide.title)}" aria-current="${index === 0 ? "page" : "false"}"><span></span></button>
  `).join("");

  dom.thumbnails.innerHTML = slides.map((slide, index) => `
    <button type="button" class="thumbnail-item${index === 0 ? " is-active" : ""}" data-go-to="${index}" aria-label="第 ${index + 1} 页：${escapeHTML(slide.title)}">
      <span class="thumbnail-preview"><span class="thumbnail-scale slide slide-${slide.type} is-active">${renderThumbnail(slide)}</span></span>
      <span class="thumbnail-meta"><b>${String(index + 1).padStart(2, "0")}</b><span>${escapeHTML(slide.title)}</span></span>
    </button>
  `).join("");
}

function renderThumbnail(slide) {
  return renderers[slide.type](slide)
    .replace(/\s(?:href|type|data-action|data-go-to)="[^"]*"/g, "")
    .replace(/<button\b/g, "<span")
    .replace(/<\/button>/g, "</span>")
    .replace(/<a\b/g, "<span")
    .replace(/<\/a>/g, "</span>");
}

function cacheDOM() {
  dom.app = document.getElementById("app");
  dom.stage = document.getElementById("slide-stage");
  dom.shell = document.getElementById("stage-shell");
  dom.dots = document.getElementById("dot-navigation");
  dom.thumbnails = document.getElementById("thumbnail-list");
  dom.rail = document.getElementById("thumbnail-rail");
  dom.edge = document.getElementById("left-edge-trigger");
  dom.counter = document.getElementById("page-counter");
  dom.railCount = document.getElementById("rail-count");
  dom.pixelTransition = document.getElementById("pixel-transition");
  dom.scanTransition = document.getElementById("scan-transition");
  dom.loadingTransition = document.getElementById("loading-transition");
  dom.status = document.getElementById("screen-reader-status");
}

function createPixelGrid() {
  dom.pixelTransition.innerHTML = Array.from({ length: 96 }, (_, index) => {
    const row = Math.floor(index / 12);
    const column = index % 12;
    return `<i style="--delay:${(row + column) * 5}ms"></i>`;
  }).join("");
}

function resizeStage() {
  const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
  document.documentElement.style.setProperty("--stage-scale", scale.toFixed(5));
}

function updateUI(index) {
  document.querySelectorAll(".nav-dot").forEach((dot, i) => {
    dot.classList.toggle("is-active", i === index);
    dot.setAttribute("aria-current", i === index ? "page" : "false");
  });
  document.querySelectorAll(".thumbnail-item").forEach((item, i) => item.classList.toggle("is-active", i === index));
  const label = `${String(index + 1).padStart(2, "0")} / ${String(slides.length).padStart(2, "0")}`;
  dom.counter.textContent = label;
  dom.railCount.textContent = label;
  dom.status.textContent = `第 ${index + 1} 页，共 ${slides.length} 页：${slides[index].title}`;
  const activeThumbnail = dom.thumbnails.querySelector(`.thumbnail-item[data-go-to="${index}"]`);
  if (dom.rail.classList.contains("is-open") && activeThumbnail) activeThumbnail.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

function activateSlide(nextIndex, direction = 1, animateSlide = false) {
  const currentSlide = dom.stage.querySelector(`[data-slide-index="${state.current}"]`);
  const nextSlide = dom.stage.querySelector(`[data-slide-index="${nextIndex}"]`);
  if (!currentSlide || !nextSlide) return;

  if (animateSlide) {
    currentSlide.classList.add(direction > 0 ? "slide-exit-left" : "slide-exit-right");
    nextSlide.classList.add("is-active", direction > 0 ? "slide-enter-right" : "slide-enter-left");
    nextSlide.setAttribute("aria-hidden", "false");
    requestAnimationFrame(() => requestAnimationFrame(() => nextSlide.classList.add("slide-enter-run")));
    window.setTimeout(() => {
      currentSlide.classList.remove("is-active", "slide-exit-left", "slide-exit-right");
      currentSlide.setAttribute("aria-hidden", "true");
      nextSlide.classList.remove("slide-enter-right", "slide-enter-left", "slide-enter-run");
    }, 560);
  } else {
    currentSlide.classList.remove("is-active");
    currentSlide.setAttribute("aria-hidden", "true");
    nextSlide.classList.add("is-active");
    nextSlide.setAttribute("aria-hidden", "false");
  }

  state.current = nextIndex;
  updateUI(nextIndex);
  restartSlideAnimations(nextSlide);
}

function restartSlideAnimations(slide) {
  slide.classList.remove("slide-awake");
  void slide.offsetWidth;
  slide.classList.add("slide-awake");
}

function goToSlide(nextIndex) {
  const target = Number(nextIndex);
  if (!Number.isInteger(target) || target < 0 || target >= slides.length || target === state.current || state.locked) return;

  const direction = target > state.current ? 1 : -1;
  const transition = slides[target].transition;
  if (state.reducedMotion) {
    activateSlide(target, direction, false);
    return;
  }

  state.locked = true;
  const unlock = (duration) => window.setTimeout(() => { state.locked = false; }, duration);

  if (transition === "pixel-slide") {
    activateSlide(target, direction, true);
    unlock(580);
    return;
  }

  if (transition === "scan-line") {
    dom.scanTransition.classList.add("is-running");
    window.setTimeout(() => activateSlide(target, direction, false), 280);
    window.setTimeout(() => dom.scanTransition.classList.remove("is-running"), 700);
    unlock(720);
    return;
  }

  if (transition === "ui-loading") {
    dom.loadingTransition.classList.add("is-running");
    window.setTimeout(() => activateSlide(target, direction, false), 390);
    window.setTimeout(() => dom.loadingTransition.classList.remove("is-running"), 760);
    unlock(780);
    return;
  }

  dom.pixelTransition.classList.add("is-covering");
  window.setTimeout(() => activateSlide(target, direction, false), 310);
  window.setTimeout(() => dom.pixelTransition.classList.add("is-revealing"), 335);
  window.setTimeout(() => dom.pixelTransition.classList.remove("is-covering", "is-revealing"), 720);
  unlock(740);
}

function nextSlide() { goToSlide(state.current + 1); }
function previousSlide() { goToSlide(state.current - 1); }

function showRail() {
  window.clearTimeout(state.hideRailTimer);
  dom.rail.classList.add("is-open");
  dom.edge.classList.add("is-active");
}

function scheduleRailHide() {
  window.clearTimeout(state.hideRailTimer);
  state.hideRailTimer = window.setTimeout(() => {
    dom.rail.classList.remove("is-open");
    dom.edge.classList.remove("is-active");
  }, 260);
}

function bindEvents() {
  window.addEventListener("resize", resizeStage, { passive: true });
  document.addEventListener("keydown", (event) => {
    if (event.key === "ArrowRight") { event.preventDefault(); nextSlide(); }
    if (event.key === "ArrowLeft") { event.preventDefault(); previousSlide(); }
    if (event.key === "Home") { event.preventDefault(); goToSlide(0); }
    if (event.key === "End") { event.preventDefault(); goToSlide(slides.length - 1); }
  });

  document.addEventListener("click", (event) => {
    const actionTarget = event.target.closest("[data-action], [data-go-to], a, button");
    if (actionTarget) {
      const action = actionTarget.dataset.action;
      if (action === "next") nextSlide();
      if (action === "replay") goToSlide(0);
      if (actionTarget.dataset.goTo !== undefined) goToSlide(Number(actionTarget.dataset.goTo));
      return;
    }
    if (event.target.closest(".thumbnail-rail, .dot-navigation")) return;
    if (event.clientX < window.innerWidth / 2) previousSlide();
    else nextSlide();
  });

  dom.edge.addEventListener("pointerenter", showRail);
  dom.edge.addEventListener("pointerleave", scheduleRailHide);
  dom.rail.addEventListener("pointerenter", showRail);
  dom.rail.addEventListener("pointerleave", scheduleRailHide);
}

function init() {
  cacheDOM();
  renderDeck();
  createPixelGrid();
  resizeStage();
  bindEvents();
  restartSlideAnimations(dom.stage.querySelector(".slide.is-active"));
}

document.addEventListener("DOMContentLoaded", init);
