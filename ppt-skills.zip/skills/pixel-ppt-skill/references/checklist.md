# Pixel Deck Checklist

Run this after generating or editing a deck.

## P0 · Must pass

- `index.html`, `style.css`, `script.js` and the local WOFF2 font all exist.
- The deck opens directly with `file://`; it has no CDN, `fetch()`, module script or build dependency.
- The internal stage remains exactly 1920×1080 and scales proportionally without cropping.
- The first three slides are `cover`, `agenda`, `section`; the last slide is `ending`.
- Every slide has a unique `id`, supported `type`, valid `transition`, `title` and `content` object.
- Agenda targets use current zero-based slide indices after pages are inserted or deleted.
- Bottom dots, page counter and thumbnails show the same number of pages as the data array.
- Keyboard arrows, page-side click zones, dots and thumbnails all change the same active state.
- Buttons, links, dots and thumbnails do not trigger background click navigation.
- Left thumbnail rail opens from the 80px edge and hides after the pointer leaves.
- No page content overlaps the bottom pixel floor, navigation dots or 1920×1080 boundary.
- `intro`, `product` and `case` images use local `assets/images/` paths and `object-fit: contain`.
- Every image has useful alt text and remains paired with its source paragraph or section.
- PDF print mode produces one 16:9 page per slide and hides all browser navigation UI.

## P1 · Visual compare

- Use large pale-blue fields, dark-blue hard pixel borders and restrained pink/purple accents.
- Preserve Press Start 2P for short English display text; use the Chinese sans-serif fallback for Chinese body copy.
- Cover keeps a dominant two-line pixel title, city horizon, START button and two characters.
- Agenda reads as a level-select menu with left list and right game illustration.
- Section pages use a dark-blue field, oversized chapter number and block-spread decoration.
- Content pages retain the top HUD, hearts, grid, clouds and bottom terrain.
- Cards of the same level remain visually consistent; do not highlight the last item by default.
- Charts use HTML/CSS/SVG, clear labels and zero decorative 3D effects.
- Thumbnail previews show the actual slide design, including the cover title.

## P2 · Content quality

- One slide carries one dominant idea.
- Preserve user wording unless splitting, shortening a title or creating navigation requires edits.
- Prefer extra pages over shrinking text below comfortable presentation size.
- Delete unused placeholder cards; duplicate a coherent layout when more items are needed.
- Keep section order, image order and data labels consistent with the source material.
- Replace demo email, project names, KPI values and sample labels before final delivery.
