# Pixel Content Layouts

Use these types inside the `slides` array in `script.js`. Copy the nearest example, then replace its content. Keep the renderer type unchanged unless a genuinely new visual structure is required.

## Shared page contract

```js
{
  id: "unique-kebab-id",
  type: "data",
  title: "Thumbnail title",
  transition: "pixel-block",
  content: {}
}
```

Choose transitions predictably:

- `pixel-block`: major visual reveal, cover-like or high-impact page.
- `scan-line`: analytical, timeline and chart pages.
- `pixel-slide`: sequential story, process or case continuation.
- `ui-loading`: product, team or mode-switch page.

## L01 · Data / KPI dashboard

Use for 3-6 headline metrics. Keep values short and pair each with a label and compact delta.

```js
{
  id: "key-metrics", type: "data", title: "Key Metrics", transition: "pixel-block",
  content: {
    title: "NUMBERS", subtitle: "关键指标 / KEY METRICS",
    metrics: [
      { icon: "◆", value: "98%", label: "客户满意度", delta: "+12%" },
      { icon: "♟", value: "780", label: "活跃客户", delta: "+28%" },
      { icon: "▣", value: "60+", label: "覆盖城市", delta: "+09" }
    ]
  }
},
```

## L02 · Intro / image and text

Use for a product introduction, context or one visual proof. Omit `image` to keep the built-in retro horizon illustration.

```js
{
  id: "product-intro", type: "intro", title: "About Product", transition: "pixel-block",
  content: {
    title: "WHAT WE DO_?", subtitle: "关于我们的产品",
    body: "用一段简洁正文解释产品、机会或核心判断。",
    tags: ["PLAYFUL", "EFFICIENT", "SCALABLE"],
    image: "assets/images/product-overview.png",
    imageAlt: "产品界面总览"
  }
},
```

## L03 · Timeline

Use for 3-5 chronological milestones. Keep time, English stage name and Chinese explanation in each tuple.

```js
{
  id: "roadmap", type: "timeline", title: "Timeline", transition: "scan-line",
  content: {
    title: "TIMELINE", subtitle: "从概念验证到规模增长",
    steps: [
      ["Q1", "DISCOVER", "用户研究"],
      ["Q2", "DESIGN", "产品原型"],
      ["Q3", "LAUNCH", "市场发布"],
      ["Q4", "LEVEL UP", "规模增长"]
    ]
  }
},
```

## L04 · Flow chart

Use for 3-5 ordered actions. Duplicate the existing icon sequence only when adding a sixth renderer state.

```js
{
  id: "mission-flow", type: "flow", title: "Flow Chart", transition: "pixel-slide",
  content: {
    title: "MISSION FLOW", subtitle: "一条清晰、可复用的增长路径",
    steps: [
      ["01", "INPUT", "收集信号"],
      ["02", "MAP", "识别机会"],
      ["03", "BUILD", "快速构建"],
      ["04", "TEST", "持续验证"],
      ["05", "WIN", "放大成果"]
    ]
  }
},
```

## L05 · Team

Use for 3-5 peers. Keep each tuple as name, role and short fallback mark; the renderer supplies the pixel avatar.

```js
{
  id: "team", type: "team", title: "Team", transition: "ui-loading",
  content: {
    title: "MEET THE TEAM", subtitle: "小队成员 / PLAYER SELECT",
    members: [["MIA", "PRODUCT", "A"], ["LEO", "DESIGN", "B"], ["NOVA", "TECH", "C"], ["KAI", "GROWTH", "D"]]
  }
},
```

## L06 · Product system

Use for a product hero, 3-5 features and three parameter bars. Omit `image` to use the built-in handheld-console screen.

```js
{
  id: "product", type: "product", title: "Product", transition: "ui-loading",
  content: {
    title: "PRODUCT SYSTEM", subtitle: "一套工具，解锁完整工作流",
    image: "assets/images/product.png", imageAlt: "产品主界面",
    features: ["实时数据面板", "智能任务编排", "模块化内容系统", "多端协作体验"],
    specs: [["SPEED", "98"], ["POWER", "86"], ["EASE", "94"]]
  }
},
```

## L07 · Market analysis

Use for five time-series values and three summary ratios. `bars` and `years` must have equal lengths; the built-in trend polyline is tuned for five points.

```js
{
  id: "market", type: "analysis", title: "Market Analysis", transition: "scan-line",
  content: {
    title: "MARKET ANALYSIS", subtitle: "趋势正在加速，窗口已经打开",
    bars: [34, 48, 57, 71, 86], years: ["22", "23", "24", "25", "26"],
    ratios: [["48%", "市场增速"], ["72%", "用户意愿"], ["3.6X", "价值空间"]]
  }
},
```

## L08 · Case study

Use for one case visual, one short narrative and three measurable outcomes. Omit `image` to keep the built-in orbit-city illustration.

```js
{
  id: "case-orbit", type: "case", title: "Case Study", transition: "pixel-slide",
  content: {
    title: "CASE STUDY", subtitle: "一次从 0 到 1 的通关记录", client: "PROJECT ORBIT",
    body: "说明背景、关键动作、周期和最终变化。",
    image: "assets/images/case.png", imageAlt: "案例项目结果界面",
    results: [["+126%", "转化率"], ["-38%", "操作时间"], ["4.8", "用户评分"]]
  }
},
```

## L09 · Comparison

Use for a symmetric before/after or plan comparison. Keep both sides at the same item count.

```js
{
  id: "comparison", type: "comparison", title: "Comparison", transition: "ui-loading",
  content: {
    title: "CHOOSE YOUR MODE", subtitle: "旧路径 VS 新体验",
    left: { name: "CLASSIC", badge: "BEFORE", items: ["流程分散", "反馈延迟", "维护成本高"] },
    right: { name: "PIXEL PRO", badge: "AFTER", items: ["统一工作台", "实时反馈", "模块化扩展"] }
  }
},
```

## L10 · Ending

Keep this as the final slide. Replace all demo contact information.

```js
{
  id: "ending", type: "ending", title: "Game Clear", transition: "pixel-block",
  content: {
    kicker: "MISSION COMPLETE", title: "GAME CLEAR!", subtitle: "下一关，和我们一起开始。",
    contact: "hello@example.com", action: "REPLAY"
  }
}
```

## Additional section pages

Insert this before each major chapter and update the following agenda indices:

```js
{
  id: "section-02", type: "section", title: "Chapter 02", transition: "pixel-slide",
  content: { number: "02", kicker: "CHAPTER TWO", title: "SECTION\nTITLE", text: "一句话说明本章节目标。" }
},
```

## Image adaptation

- Copy all selected files into `assets/images/` and use relative paths.
- Use `imageAlt` to describe what the image proves, not merely “图片”。
- Preserve full content with `object-fit: contain`; allow background letterboxing.
- If one source section has multiple images, extend the renderer with a grid or split into adjacent pages. Do not silently drop images.
- Keep images with their source text and preserve the source order across slides.
