#!/usr/bin/env node

import { cpSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const force = args.includes('--force');
const targetArg = args.find((arg) => !arg.startsWith('--'));

if (!targetArg) {
  console.error('Usage: node scripts/scaffold-deck.mjs <output-directory> [--force]');
  process.exit(2);
}

const scriptDir = dirname(fileURLToPath(import.meta.url));
const source = resolve(scriptDir, '../assets/template');
const target = resolve(targetArg);

if (!existsSync(source)) {
  console.error(`Template directory is missing: ${source}`);
  process.exit(1);
}

if (existsSync(target) && readdirSync(target).length > 0 && !force) {
  console.error(`Output directory is not empty: ${target}`);
  console.error('Choose an empty directory or pass --force to replace matching template files.');
  process.exit(1);
}

mkdirSync(target, { recursive: true });
cpSync(source, target, { recursive: true, force: true });

console.log(`Pixel deck created: ${target}`);
console.log(`Open: ${resolve(target, 'index.html')}`);
console.log('Edit the slides array in script.js, then run validate-deck.mjs.');
