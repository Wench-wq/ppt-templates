#!/usr/bin/env node

import { existsSync, readFileSync, statSync } from 'node:fs';
import { dirname, extname, join, resolve } from 'node:path';
import vm from 'node:vm';

const input = process.argv[2];
const isTemplate = process.argv.includes('--template');

if (!input) {
  console.error('Usage: node scripts/validate-deck.mjs <deck-directory|index.html> [--template]');
  process.exit(2);
}

const resolved = resolve(input);
const root = extname(resolved).toLowerCase() === '.html' ? dirname(resolved) : resolved;
const htmlFile = extname(resolved).toLowerCase() === '.html' ? resolved : join(root, 'index.html');
const cssFile = join(root, 'style.css');
const jsFile = join(root, 'script.js');
const errors = [];
const warnings = [];
let slides = [];
let renderers = {};
let renderThumbnail;

for (const file of [htmlFile, cssFile, jsFile]) {
  if (!existsSync(file)) errors.push(`Missing required file: ${file}`);
}

if (errors.length) finish();

const html = readFileSync(htmlFile, 'utf8');
const css = readFileSync(cssFile, 'utf8');
const js = readFileSync(jsFile, 'utf8');

if (!/<link\b[^>]*href="style\.css"/.test(html)) errors.push('index.html must load style.css with a relative path.');
if (!/<script\b[^>]*src="script\.js"[^>]*defer/.test(html)) errors.push('index.html must load script.js with defer.');
if (/type="module"|\bfetch\s*\(/.test(html + js)) errors.push('Deck must not require ES modules or fetch().');
if (/https?:\/\//.test(html + css + js)) errors.push('Remote URL found; the deck must run fully offline.');
if (!js.includes('SLIDES_DATA_START') || !js.includes('SLIDES_DATA_END')) errors.push('script.js is missing slide data boundary comments.');
if (!/width:\s*1920px/.test(css) || !/height:\s*1080px/.test(css)) errors.push('CSS must preserve a 1920 × 1080 stage.');
if (!/innerWidth\s*\/\s*1920/.test(js) || !/innerHeight\s*\/\s*1080/.test(js)) errors.push('Responsive scale must derive from 1920 × 1080.');
if (!/@page[\s\S]*?20in\s+11\.25in/.test(css)) errors.push('Print CSS must preserve a 16:9 PDF page.');

const fontFile = join(root, 'assets/fonts/press-start-2p-latin.woff2');
if (!existsSync(fontFile) || statSync(fontFile).size < 1000) errors.push('Local Press Start 2P font is missing or invalid.');

try {
  const runnable = js
    .replace('const slides =', 'var slides = globalThis.__slides =')
    .replace('const renderers =', 'var renderers = globalThis.__renderers =');
  const sandbox = {
    window: {
      matchMedia: () => ({ matches: false }),
      addEventListener: () => {},
      setTimeout: () => 0,
      clearTimeout: () => {},
      innerWidth: 1920,
      innerHeight: 1080
    },
    document: { addEventListener: () => {} },
    console,
    Error,
    String,
    Number,
    Array,
    Math
  };
  vm.createContext(sandbox);
  vm.runInContext(runnable, sandbox, { filename: jsFile, timeout: 3000 });
  slides = sandbox.__slides;
  renderers = sandbox.__renderers;
  renderThumbnail = sandbox.renderThumbnail;
} catch (error) {
  errors.push(`script.js could not be evaluated: ${error.message}`);
}

if (!Array.isArray(slides) || !slides.length) {
  errors.push('No slides found in the slides array.');
} else {
  const allowedTypes = new Set(['cover', 'agenda', 'section', 'data', 'intro', 'timeline', 'flow', 'team', 'product', 'analysis', 'case', 'comparison', 'ending']);
  const transitions = new Set(['pixel-block', 'scan-line', 'pixel-slide', 'ui-loading']);
  const ids = new Set();

  if (slides[0]?.type !== 'cover') errors.push('Slide 1 must be type "cover".');
  if (slides[1]?.type !== 'agenda') errors.push('Slide 2 must be type "agenda".');
  if (slides[2]?.type !== 'section') errors.push('Slide 3 must be type "section".');
  if (slides.at(-1)?.type !== 'ending') errors.push('The last slide must be type "ending".');
  if (!isTemplate && slides.length < 5) errors.push('Final deck needs at least one content slide between section and ending.');

  slides.forEach((slide, index) => {
    const number = index + 1;
    if (!slide || typeof slide !== 'object') {
      errors.push(`Slide ${number} is not an object.`);
      return;
    }
    if (!slide.id || ids.has(slide.id)) errors.push(`Slide ${number} has a missing or duplicate id.`);
    ids.add(slide.id);
    if (!allowedTypes.has(slide.type)) errors.push(`Slide ${number} has invalid type "${slide.type}".`);
    if (!transitions.has(slide.transition)) errors.push(`Slide ${number} has invalid transition "${slide.transition}".`);
    if (!slide.title) errors.push(`Slide ${number} is missing title.`);
    if (!slide.content || typeof slide.content !== 'object') errors.push(`Slide ${number} is missing content.`);
    if (typeof renderers?.[slide.type] !== 'function') errors.push(`Slide ${number} has no renderer for type "${slide.type}".`);

    try {
      const markup = renderers?.[slide.type]?.(slide) ?? '';
      if (markup.length < 100) errors.push(`Slide ${number} renderer returned incomplete markup.`);
      for (const match of markup.matchAll(/\bsrc="([^"]+)"/g)) {
        const ref = match[1].split('?')[0];
        if (!ref.startsWith('assets/')) continue;
        if (!existsSync(join(root, ref))) errors.push(`Slide ${number} references missing asset: ${ref}`);
      }
    } catch (error) {
      errors.push(`Slide ${number} renderer failed: ${error.message}`);
    }
  });

  const agendaItems = slides[1]?.content?.items;
  if (Array.isArray(agendaItems)) {
    agendaItems.forEach((item, index) => {
      const target = item?.[3];
      if (!Number.isInteger(target) || target < 0 || target >= slides.length) {
        errors.push(`Agenda item ${index + 1} has invalid zero-based target index.`);
      }
    });
  }

  if (typeof renderThumbnail === 'function') {
    const thumbs = slides.map((slide) => renderThumbnail(slide)).join('');
    if (/<\/?(?:button|a)\b/i.test(thumbs) || /data-(?:action|go-to)=/i.test(thumbs)) {
      errors.push('Thumbnail markup contains nested interactive controls.');
    }
  } else {
    errors.push('renderThumbnail() is missing.');
  }

  if (isTemplate) {
    const expected = ['cover', 'agenda', 'section', 'data', 'intro', 'timeline', 'flow', 'team', 'product', 'analysis', 'case', 'comparison', 'ending'];
    if (slides.length !== expected.length || !expected.every((type, index) => slides[index]?.type === type)) {
      errors.push('Template must contain the complete ordered 13-page example.');
    }
  } else if (js.includes('hello@pixelconcept.studio')) {
    warnings.push('Default demo contact address is still present.');
  }
}

finish();

function finish() {
  if (warnings.length) {
    console.warn('Warnings:');
    warnings.forEach((warning) => console.warn(`- ${warning}`));
  }
  if (errors.length) {
    console.error('Pixel deck validation failed:');
    errors.forEach((error) => console.error(`- ${error}`));
    process.exit(1);
  }
  console.log(`Pixel deck validation passed: ${slides.length} slide(s).`);
}
